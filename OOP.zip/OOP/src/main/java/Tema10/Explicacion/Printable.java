package Tema10.Explicacion;

public interface Printable {
 
    void print(String message);

}
