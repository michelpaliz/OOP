package Tema10.Ejercicios.Propios.Ejercicio7;

public interface IMoneda {
    double monedas(double monedaLocal, double monedaExtr);

}
