package Tema10.Ejercicios.Propios.Ejercicio11.actores;

public class Profesor {
    private int ID;
    private String nombre;
    private double sueldo;
}
