package Tema10.Ejercicios.Propios.Ejercicio7;

import java.util.HashMap;

public class Ejercicio7 {

    public HashMap<String, Double> monedas = new HashMap<>();

    public Ejercicio7() {

    }

    public void menuMonedas(){
        monedas.put("USD",0.21);
        
    }
  

}
