package Tema10.Ejercicios.Propios.Ejercicio2;

public interface IEstadisticas {

public double minimo(){
return 0;
}

public double maximo(){
    return 0;
}

public double sumatorio(){
    return 0;
}

public double media(){
    return 0;
}

public double moda(){
    return 0;
}


}
