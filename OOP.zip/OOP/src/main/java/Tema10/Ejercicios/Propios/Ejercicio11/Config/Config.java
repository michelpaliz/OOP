package Tema10.Ejercicios.Propios.Ejercicio11.Config;

public class Config {
    public static final int STARTER_ID = 0;
    
}
