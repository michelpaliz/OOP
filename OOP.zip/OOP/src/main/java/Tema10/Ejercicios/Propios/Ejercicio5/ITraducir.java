package Tema10.Ejercicios.Propios.Ejercicio5;

public interface ITraducir {

    String introducirPareja(String palabra, String palabraVal);
    String traducirPalabra(String palabra);
    
}
