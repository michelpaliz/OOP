package Tema10.Ejercicios.Propios.Ejercicio11;

public class App {

    public App(){

    }

    public void menu(){
        
    }


    
}
