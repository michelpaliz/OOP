package Tema10.Ejercicios.Propios.Ejercicio2;

public class Ejercicio2 {
    
}
