package Tema10.Ejercicios.Clases.ejercicio05;

public enum Genero {
    M, F
}
