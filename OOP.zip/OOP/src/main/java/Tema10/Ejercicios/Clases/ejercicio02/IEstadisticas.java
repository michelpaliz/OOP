package Tema10.Ejercicios.Clases.ejercicio02;

public interface IEstadisticas {
    double minimo();
    double maximo();
    double sumatorio();
    double media();
    double moda();
}
