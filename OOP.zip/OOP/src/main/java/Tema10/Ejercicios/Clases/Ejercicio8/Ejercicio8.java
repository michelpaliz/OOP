package Tema10.Ejercicios.Clases.Ejercicio8;

public class Ejercicio8 {
    
    public Ejercicio8(){
        
    }

}
