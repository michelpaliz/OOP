package Tema10.Ejercicios.Clases.ejercicio05;

import java.util.ArrayList;
import java.util.HashMap;

public class Consulta implements IConsulta {

    @Override
    public int[] majorMenorArray(ArrayList<Paciente> pacientes) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int[] pacientsPorSexoArray(ArrayList<Paciente> pacientes) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public double imc(Paciente paciente) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int edad(Paciente paciente) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public HashMap<String, String> imcMensaje(ArrayList<Paciente> pacientes) {
        // TODO Auto-generated method stub
        return null;
    }
    
}
