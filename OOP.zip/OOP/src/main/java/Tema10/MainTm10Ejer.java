package Tema10;

import java.util.Arrays;

import Tema10.Ejercicios.Propios.Ejercicio1.Ejercicio1;
import Tema10.Ejercicios.Propios.Ejercicio10.Empresa;
import Tema10.Ejercicios.Propios.Ejercicio2.ArrayLisEstadisticas;
import Tema10.Ejercicios.Propios.Ejercicio3.Pila;
import Tema10.Ejercicios.Propios.Ejercicio7.Ejercicio7;
import Tema10.Ejercicios.Propios.Ejercicio8.Ejercicio8;
import Tema10.Explicacion.ForEach.Example;
// import Tema10.Ejercicios.Propios.Ejercicio10.App;
import Tema10.Ejercicios.Propios.Ejercicio11.App;
import Tema10.Explicacion.Maps.*;
// import Tema10.Explicacion.comparable.App;
import Tema9.EjerciciosTm9.Ejercicio9;

public class MainTm10Ejer {

    public static void main(String[] args) {
        // *Ejercicios Clases
        // jericicio1
        // Ejercicio1 ejercicio1 = new Ejercicio1();
        // Ejercicio2
        // ArrayLisEstadisticas test = new ArrayLisEstadisticas(10);
        // System.out.println(ejercicio1);
        // *Ejercicios Propios
        // Ejercicio3
        // Pila ejercicio3 = new Pila();
        // System.out.println((ejercicio3));
        // Explicacion
        // EjemploMap ejemplo = new EjemploMap();
        // System.out.println(ejemplo);
        // Ejercicio7 mon = new Ejercicio7();
        // System.out.println(mon);
        // Ejercicio8 start = new Ejercicio8();
        // Ejercicio9 start = new Ejercicio9();
        // Ejercicio10
        App Ejercicio10 = new App();
        // System.out.println("Explicacion ");
        // Example start = new Example();
        // App start = new App();
        App Ejercicio11 =  new App();

    }

}
