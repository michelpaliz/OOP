package Tema9;

import Tema9.EjerciciosTm9.*;

public class MainTm9 {

    public static void main(String[] args) {

        System.out.println("EJERCICIOS DEL TEMA 9");
        // Ejercicio1.Ejercicio1();
        // Ejercicio2.Ejercicio2();
        // Ejercicio3.Ejercicio03();
        // Ejercicio4.Ejercicio4();
        // Ejercicio5 ejercicio5 = new Ejercicio5();
        // ejercicio5.Ejercicio5();
        // Ejercicio6.Ejercicio6();
        // Ejercicio7.Ejercicio7();
        // Ejercicio8.Ejercicio8();
        Ejercicio10.Ejercicio10();

    }
}
