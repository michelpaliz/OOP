package Tema9.examen;
public class MainExamen {
    public static final boolean DEBUG = true;

    public static void main(String[] args) {
        Programa1 programa1 = new Programa1();
    }
}
