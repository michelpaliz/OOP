package Testing;

import Testing.Hashmap.Testing;
import Testing.menu.Menu;
import Util.menu;

public class Main {

    public static void main(String[] args) {
        // Testing t1 = new Testing();
        // t1.empIds.put("Michael", 1234);
        // t1.empIds.put("Michael", 12345); // this will overwritte the current value to
        // the old one
        // t1.empIds.put("Jhoan", 1234);

        // System.out.println(t1.empIds);
        // System.out.println(t1.empIds.get("Michael")); // it's case sensitive
        // System.out.println(t1.empIds.containsKey("Jhoan"));
        // System.out.println(t1.empIds.containsValue(1234));
        // // System.out.println(t1.empIds.replace(key, oldValue, newValue));
        // System.out.println(t1.empIds.putIfAbsent("Steve", 22222)); // returns null
        // // bcs it doens exists
        // System.out.println(t1.empIds);
        // System.out.println(t1.empIds.remove("Steve"));

        System.out.println("Start menu");
        Menu start = new Menu();

        System.out.println(start);

    }
}
