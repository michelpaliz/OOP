package Testing.menu;

import Util.Control;

public class Menu {

    // public Menu() {
    // String title = "title";
    // String[] sentences = { "Hello", "bye", "goodbye", "helloagain" };

    // System.out.println("This is the lenght of the array");
    // System.out.println(sentences.length);

    // menuGenerator(title, sentences);
    // }

    // public void menuGenerator(String title, String[] sentence) {
    // System.out.printf("*****%S********\n\n", title);
    // for (int i = 0; i < sentence.length; i++) {
    // sentence[i] = String.format("%d %S\n", (i + 1), sentence[i]);
    // System.out.println(sentence[i]);
    // }
    // }

    public Menu() {
        String message = "introduce your answer ";
        char validate[] = { 's', 'n', 'o' };
        System.out.println(Control.one(message, validate));

    }

}
