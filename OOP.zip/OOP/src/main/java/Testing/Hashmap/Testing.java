package Testing.Hashmap;

import java.util.HashMap;

public class Testing {

    public HashMap<String, Integer> empIds = new HashMap<>();

}
