package Tema8.EjemplosTema8.Tema8Adv.Ejercicio6;

public enum ResultadoOperacion {
    ADDED, UPDATED, DELETED, INSUFFICIENT_STOCK, NOT_FOUND, SPACE_LIMIT_EXCEEDED
}
