package Tema8.EjemplosTema8.Tema8Adv;

import Tema8.EjemplosTema8.Tema8Adv.Ejercicio6.Ejercicio6;

public class Main {

    public static void main(String[] args) {
        // Ejercicio1 ejercicio1 = new Ejercicio1();
        // Ejercicio2 ejercicio2 = new Ejercicio2();
        // Ejercicio3a ejercicio3a = new Ejercicio3a(100,5);
        // Ejercicio3b ejercicio3b = new Ejercicio3b(100,5);
        // Ejercicio4 ejercicio4 = new Ejercicio4();
        // Ejercicio5 ejercicio5 = new Ejercicio5();
        Ejercicio6 ejercicio6 = new Ejercicio6(100);
        // Ejercicio7 ejercicio7 = new Ejercicio7();
    }
}
