package Tema8.EjemplosTema8.Tema8Adv.Ejercicio1;

public enum ModalidadSeguro {
    TERCEROS, TODO_RIESGO
}
