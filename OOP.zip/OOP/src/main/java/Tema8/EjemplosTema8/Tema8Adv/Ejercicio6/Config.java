package Tema8.EjemplosTema8.Tema8Adv.Ejercicio6;

public class Config {
    public static final int MAX_BICICLETAS = 100;
}
