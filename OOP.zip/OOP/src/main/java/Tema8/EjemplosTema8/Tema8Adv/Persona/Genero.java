package Tema8.EjemplosTema8.Tema8Adv.Persona;

public enum Genero {
    MASCULINO, FEMENINO, TRANSEXUAL
}
