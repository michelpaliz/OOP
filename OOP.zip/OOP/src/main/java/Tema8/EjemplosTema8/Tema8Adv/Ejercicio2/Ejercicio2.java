package Tema8.EjemplosTema8.Tema8Adv.Ejercicio2;

public class Ejercicio2 {
    public Ejercicio2() {
        Asignatura a1 = new Asignatura(1017, "Programación",1);
        System.out.println(a1.toString());
    }
}
