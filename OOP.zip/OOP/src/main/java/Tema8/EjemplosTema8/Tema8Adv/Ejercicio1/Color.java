package Tema8.EjemplosTema8.Tema8Adv.Ejercicio1;

public enum Color {
    BLANCO, ROJO, NEGRO, AZUL, VERDE, AMARILLO, GRIS
}
