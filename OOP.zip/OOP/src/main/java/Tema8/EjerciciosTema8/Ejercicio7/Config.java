package Tema8.EjerciciosTema8.Ejercicio7;

public class Config {
    
    public static long anyo, mes, dia, hora, minuto, segundo;
    public static int temp, ppm, tens;
    public static final int MAX_HOUR = 23;
    public static final int MIN_HOUR = 1;
    public static final int MAX_MIN = 59;
    public static final int MIN_MIN = 1;
    public static final int MIN_SEGUNDO = 1;
    public static final int MAX_SEGUNDO = 59;
    public static final int MIN_ANYO = 1;
    public static final int MAX_ANYO = 23;
    public static final int MES_MAX = 12;
    public static final int MES_MIN = 1;
    public static final int DIA_MIN = 1;
    public static final int DIA_MAX = 31;
    // *Revisones
    public static final int MIN_TEMP = 34;
    public static final int MAX_TEMP = 42;
    public static final int MIN_PPM = 50;
    public static final int MAX_PPM = 135;
    public static final int MIN_TENS = 90;
    public static final int MAX_TENS = 140;

}
