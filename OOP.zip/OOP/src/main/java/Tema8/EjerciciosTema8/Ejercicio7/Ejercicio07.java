package Tema8.EjerciciosTema8.Ejercicio7;

import Util.Control;

public class Ejercicio07 {
    public static final boolean DEBUG = true;
    public static final int MIN_PACIENTES = 20;
    public static final double FACTOR_CRECIMIENTO = 2;

    public Ejercicio07() {
        Registro paciente = new Registro();
    }

}
