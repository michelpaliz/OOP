package Tema8.EjerciciosTema8;

import Tema8.EjerciciosTema8.Pila.CircularQueue;

//importacion de las clases

import Tema8.EjerciciosTema8.Pila.EjercicioPila;
import Tema8.EjerciciosTema8.Pila.Pila;
import Tema8.EjerciciosTema8.Primitiva.JuegoPrimitiva;
import Util.Test;


public class Main {
    public static void main(String[] args) {
        // System.out.println("EJERCICIO NUMERO 2");
        // Ejercicio02 ejercicio02 = new Ejercicio02();
        // System.out.println("EJERCICIO NUMERO 4");
        // Ejercicio04 ejercicio04 = new Ejercicio04();
        // // Ejercicio03 ejercicio03 = new Ejercicio03()
        // System.out.println("EJERCICIO NUMERO5");
        // Ejercicio05 ejercicio05 = new Ejercicio05();
        // System.out.println("EJERCICIO NUMERO 6");
        // // Ejercicio06 tienda = new Ejercicio06();
        // System.out.println("EJERCICIO NUMERO 7");
        // Ejercicio07 registro = new Ejercicio07();
        // System.out.println("PILA");
        // EjercicioPila pila = new EjercicioPila();

        // Cola<String> cola = new Cola<>();
        // cola.add

        // System.out.println("Juego de la Primitiva");
        // JuegoPrimitiva sorteo = new JuegoPrimitiva();

        // Test
        // String messageInt = "Introduce un int";
        // userInput.validarInt(messageInt);
        //
        // Test test = new Test();
        // System.out.println(test);

        Test.main();

    }

}
