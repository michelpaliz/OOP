package Tema8.EjerciciosTema8.Primitiva;

public class Config {
    static final  int MAX_NUMERO_SUERTE = 6;
    
}
