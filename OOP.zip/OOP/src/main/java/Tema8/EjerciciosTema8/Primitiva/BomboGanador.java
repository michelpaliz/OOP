package Tema8.EjerciciosTema8.Primitiva;

public class BomboGanador {
    private int[] numeracionGanadora;
    private int[] numCompGanador;// Este es el septimo numero de 1 a 43 numeros
    private int[] numReinGanador;// Este es el octavo numero de 0 a 9 numeros

    // +Todo generar numeracionGanadora
    // +Todo
}
