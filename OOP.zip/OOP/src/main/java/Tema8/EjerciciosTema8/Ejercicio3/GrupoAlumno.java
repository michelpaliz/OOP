package Tema8.EjerciciosTema8.Ejercicio3;

public enum GrupoAlumno {

    DAM1, DAM2, DAM3

}
