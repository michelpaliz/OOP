package Tema8.EjerciciosTema8.Ejercicio6;

public class Ejercicio06 {
    public static final boolean DEBUG = true;
    public static final int MIN_BICLETAS = 20;
    public static final double FACTOR_CRECIMIENTO = 2;

    public Ejercicio06() {
        Tienda bicicletas = new Tienda();
    
    }
}
