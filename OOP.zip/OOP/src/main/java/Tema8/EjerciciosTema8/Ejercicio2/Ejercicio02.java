package Tema8.EjerciciosTema8.Ejercicio2;


public class Ejercicio02 {
    public Ejercicio02() {
        Asignatura asignatura = new Asignatura("programacion",1070,"si");
        System.out.println(asignatura); //se asigana automaticamente el toString();
    }

}
