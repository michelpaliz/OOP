package OtrosEjercicios.Campeonato;

public class TablaPosiciones {
        private int puntos;
        private String [] tablaPosciones;
}
