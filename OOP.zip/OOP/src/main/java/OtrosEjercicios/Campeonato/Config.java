package OtrosEjercicios.Campeonato;

public class Config {
    
    



    
}
