package OtrosEjercicios.Campeonato;


public class Liga {

}