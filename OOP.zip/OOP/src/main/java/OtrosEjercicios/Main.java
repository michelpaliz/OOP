package OtrosEjercicios;

import OtrosEjercicios.Campeonato.App;
import OtrosEjercicios.StackOverflow.Cola;
import OtrosEjercicios.StackOverflow.Pila;

public class Main {

    public static void main(String[] args) {

        // *PILA
        // Pila metodo = new Pila();
        // metodo.size();
        // // metodo.add();
        // metodo.push();
        // metodo.contains();
        // metodo.push();
        // metodo.pop();
        // metodo.popOneElement();
        // metodo.empty();

        // *QUEUE
        // Cola metodo = new Cola();

        // metodo.size();
        // metodo.encolar();
        // System.out.println(metodo.showFirstElement());
        // metodo.removeElement();
        // metodo.desencolar();
        // metodo.ordenar();
        // metodo.mostrar();
        // metodo.removeQueue();

        //*TORNEO

        App startGame = new App();
        


    }
}
