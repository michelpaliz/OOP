package TestWorlde.Propio.Worlde;

public class Letter {
    
    private final char character;
    private final AnsiColor color;


}
