package TestWorlde.Propio.Worlde;

public class Config {
    public static final int MAX_INTENTOS = 6;
    public static final int MAX_LENGTH_WORD = 5;
}
