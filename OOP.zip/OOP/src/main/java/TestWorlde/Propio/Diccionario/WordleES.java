package TestWorlde.Propio.Diccionario;

public class WordleES {
    public static String[] words = { "aviso", "ahora", "tenis", "amigo", "lapiz", "jugar", "cable", "techo" };
}
