package TestWorlde.Propio.Diccionario;

public class WordleEN {
    static String[] words = { "start", "match", "track", "mouse" };
}
