package TestWorlde.Clase.Dictionary;

public class WordleES {
    // Clase que gestiona todos los diccionarios
    // private String[] words;
    // private int wordsCount;

    // public WordleES(String[] words){
    // this.words = words;
    // }

    // creamos esta clase para representar las palabras, despues habra otra clase
    // que elgia el idioma
    // Esta clase es para almacenar datos, no es un almacen de datos y lo ponemos
    // public
    public static String[] words = { "aviso", "ahora", "tenis", "amigo", "lapiz", "jugar", "cable", "techo" };
    



}
