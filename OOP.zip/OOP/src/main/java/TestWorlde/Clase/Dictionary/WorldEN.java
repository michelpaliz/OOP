package TestWorlde.Clase.Dictionary;

public class WorldEN {

    static String[] words = { "start", "match", "track", "mouse" };

}
