package TestWorlde.Clase.Dictionary;

public enum Language {
    EN,ES
}
