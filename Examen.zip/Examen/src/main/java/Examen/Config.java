package Examen;

public class Config {
    public static final int FACTOR_CRECIMIENTO = 2;
    
}
