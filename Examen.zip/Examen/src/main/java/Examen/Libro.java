package Examen;

import java.time.LocalDate;
import java.util.GregorianCalendar;

public class Libro {
    // Atributos de libro
    private long isb;
    private String titulo;
    private GregorianCalendar fecha;
    private Genero genero;
    private int numPaginas;
    private Autor[] autor;

    public Libro(long isb, String titulo, GregorianCalendar fecha, Genero genero, int numPaginas, Autor[] autor) {
        this.isb = isb;
        this.titulo = titulo;
        this.fecha = fecha;
        this.genero = genero;
        this.numPaginas = numPaginas;
        this.autor = autor;
    }

    public long getIsb() {
        return isb;
    }

    public String getTitulo() {
        return titulo;
    }

    public GregorianCalendar getFecha() {
        return fecha;
    }

    public Genero getGenero() {
        return genero;
    }

    public int getNumPaginas() {
        return numPaginas;
    }

    public Autor[] getAutor() {
        return autor;
    }

    @Override
    public String toString() {
        return "Libro{" +
                "isb=" + isb +
                ", titulo='" + titulo + '\'' +
                ", fecha=" + fecha +
                ", genero=" + genero +
                ", numPaginas=" + numPaginas +
                ", autor=" + autor +
                '}';
    }
}
