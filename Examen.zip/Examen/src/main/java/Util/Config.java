package Util;

public class Config {
    public static boolean correct;
    public static String userStr;
    public static int userInt;

}
