import Examen.App;
import Examen.Libro;

public class Main {

    public static void main(String[] args) {
        App start = new App();
        System.out.println(start);
    }
    
}
